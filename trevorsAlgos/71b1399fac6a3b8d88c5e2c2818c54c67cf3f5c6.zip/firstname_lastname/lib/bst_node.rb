class BSTNode
  def initialize(value)
  end
end
