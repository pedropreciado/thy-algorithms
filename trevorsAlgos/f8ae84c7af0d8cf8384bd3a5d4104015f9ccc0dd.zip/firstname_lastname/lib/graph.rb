class Vertex
  def initialize(value)

  end
end

class Edge
  def initialize(from_vertex, to_vertex, cost = 1)

  end

  def destroy!

  end
end
